import React from 'react'
import logo from './maybank-logo.png';
import './App.css'

function App() {
  return (
      <div className="App bg-main">
        <header className="App-header">
        <img src={logo} className="App-logo" alt="logo"/>
          <p>
           Maybank Digital Innovation
          </p>
         
        </header>
      </div>
  )
}

export default App
